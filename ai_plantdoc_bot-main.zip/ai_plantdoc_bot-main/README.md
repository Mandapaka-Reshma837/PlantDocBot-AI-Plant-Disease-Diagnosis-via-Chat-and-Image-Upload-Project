# ai_plantdoc_bot
AI-powered plant disease diagnosis system using Computer Vision (CNNs) and NLP. Developed for the Infosys Springboard Virtual Internship.
